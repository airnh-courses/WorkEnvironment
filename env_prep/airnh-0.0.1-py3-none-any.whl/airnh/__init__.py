from .reviews import test_trig, test_atan2, test_norm, test_normalize, test_dot, test_calcDotAngle, test_cross, test_calcCrossAngle, test_vec_shape1x3, test_vec_t, test_mat_t, test_matmul_correct, test_matmul, interactiveCrossProduct
from .bridge import bridge_main

# bridge_main()



